import React from "react";
import UserManagement from "./UserManagement/UserManagement";

function App() {
	return <UserManagement />;
}

export default App;
